#include<stdio.h>
#include<stdlib.h>

int SPQR (int C[],int n,int k)
{
	int i,count,j1,j2 ;
	i=0;
	j1=0;
	j2=0;
	count=0;
    while(i<=n)
    {
    	while(j1<=n && C[j1]-C[i]<k)
    	{
    		j1++;
		}
		while(j2<=n && C[j2]-C[i]<=k)
		{
			j2++;
		}
		count = count + j2 - j1;
		i++;
	}
	return(count);
	}




//int main (int argc,char *argv[])
int main()
{
	int i,j,n,k,l,count;
	int A[701][700],C[701];
	long int r;
//	FILE *f;
//f=fopen(argv[1],"r");  // open file
//f=fopen("testforrome.c","r");
 //   if(f == NULL) 
 //  {
 //     perror("Error in opening file");
 //     return(-1);
 //  }  
	scanf("%d",&n);  // read n
	scanf("%1d",&k);
	for ( i=1;i<=n;i++)
	   for( j=0;j<n;j++)
	   scanf("%1d",&A[i][j]);  //read all elements

	   
	   
	    
    for(i=0;i<n;i++)
    A[0][i]=0;
    for(i=1;i<n+1;i++)
      for(j=0;j<n;j++)
         A[i][j]=A[i-1][j]+A[i][j];

    r=0;     
    for(i=0;i<n;i++)
       for(j=i+1;j<n+1;j++)
        {
        	C[0]=0;
        	for(l=0;l<n;l++)
        	C[l+1] = C[l]+A[j][l]-A[i][l];    	
        	count = SPQR(C,n,k);
        	r=r+count;
		}
		 printf("%li",r);
		 printf("\n");
//	    fclose(f);
	    system("PAUSE");
	    exit(0);
	}
