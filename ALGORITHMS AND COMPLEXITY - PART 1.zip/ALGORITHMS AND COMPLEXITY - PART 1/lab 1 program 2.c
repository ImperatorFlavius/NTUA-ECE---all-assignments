#include <stdio.h>
#include <stdlib.h>
#include<math.h>

long long int findmin(long long int A[],long long int n)
{
	long long int i,min;
	min=A[0];
	for(i=1;i<n;i++)
	{
		if(A[i]<min)
			min=A[i];	
	}
	return(min);
}



long long findr(long long int A[],long long int t1,long long int k,long long int n)
{
	long long int count,i,rr;
	count=0;
	for(i=0;i<n;i++)
	count=count+t1/A[i] +1;
	if(count==k)
	{
		for(i=n-1;i>=0;i--)
		{
			if(t1%A[i]==0)
			return(i);
		}
		
	}
	else
	{
		rr=count-k;
		for(i=n-1;i>=0;i--)
		{
			if(t1%A[i]==0)
			{
				
				if(rr==0)
				return(i);
				rr=rr-1;
			}
		}
	}
}


long long fs(long long int A[],long long int t1,long long int k,long long int n) 
{
	long long int i,count;
	count=0;
	for(i=0;i<n;i++)
	count=count + t1/A[i] +1;
	if(count<k)
	return(fs(A,t1+1,k,n));
	if(count>=k)
	return(t1);	
}


long long int bs(long long int A[],long long int t1,long long int t2,long long int k,long long int n)
{
	if(t2==t1+1)
	return(t2);
	long long int i,count,mid;
	mid = t1 +(t2-t1)/2 ;
	count=0;
	for(i=0;i<n;i++)
count=count + mid/A[i] +1;
	if(count<k)
	return(bs(A,mid,t2,k,n));
if(count==k)
return(mid);
	if(count>k)
	return(bs(A,t1,mid,k,n));
}




int main ()
{
	long long int i,n,k,r,t,tmin,tmax,A[100000],minn;
	scanf("%lli",&n);  // read n
	scanf("%lli",&k);  //read k
	for ( i=0;i<n;i++)
	    scanf("%lli",&A[i]);  //read all elements
	    
if(n>=k)
{
	r=k;
	t=A[k-1];
	}
else
{
  tmin=0;
  minn=findmin(A,n);
  tmax= k*minn;
  t = bs(A,tmin,tmax,k,n);
  tmin = t-minn ;
  t= fs(A,tmin,k,n);
  r=findr(A,t,k,n);
  t=t + A[r];
  r=r+1;
}



printf("%lli",r);
 printf(" ");
 printf("%lli",t);
  printf("\n");
	    exit(0);
}
