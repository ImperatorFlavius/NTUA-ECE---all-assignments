#include <stdio.h>
#include <stdlib.h>


// Function to find out maximum profit by buying &
// selling/ a share atmost k times given stock price
// of n days

long  int max(long int x,long int y)
{
	if(x>y)
	return(x);
	else 
	return(y);
}


long  int maxProfit( int price[],  long int n,int k)
{
   	int i;
	 long int j;
    // table to store results of subproblems
    // profit[t][i] stores maximum profit using atmost
    // t transactions up to day i (including day i)
    long  int data0[n+1],data1[n+1];
 
    // For day 0, you can't earn money
    // irrespective of how many times you trade
    data0[0]=0;
    data1[0]=0;
    
 
    // profit is 0 if we don't do any transation
    // (i.e. k =0)
    for (j= 0; j <= n; j++)
        data0[j] = 0;
 
    // fill the table in bottom-up fashion
    for (i = 1; i <= k; i++)
    {
        long  int prevDiff = -99999999;
        for ( j = 1; j < n; j++)
        {
        	if(i%2==1)
        	{
            prevDiff = max(prevDiff,
                           data0[j-1] - price[j-1]);
            data1[j] = max(data1[j-1],
                               price[j] + prevDiff);
            }
            else
            {
             prevDiff = max(prevDiff,
                           data1[j-1] - price[j-1]);
            data0[j] = max(data0[j-1],
                               price[j] + prevDiff);	
			}
        }
    }
    if(k%2==0)
    return data0[n-1];
    else
    return data1[n-1];
}


int main ()
{
	int k, price[100001];
	long int n,i;
	long  int r;
	scanf("%li",&n);
	scanf("%d",&k);
	for(i=0;i<n;i++)
	  scanf("%d",&price[i]);
	  r=maxProfit(price,n,k);
	  printf("%lli",r);
	  printf("\n");
exit(0);	
	}	
