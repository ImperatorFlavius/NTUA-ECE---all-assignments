#include <stdio.h>
#include <stdlib.h>

long  int E[2501][2501];
long  int dp[2501][701];
int A[2501][2501];

void initialize(int n,int k)
{
	int i;
	for(i=0;i<=k;i++)
	{
		dp[0][i]=0;
		dp[1][i]=0;
	}
    for(i=1;i<=n;i++)
	   dp[i][1]=E[1][i];		
}


void calculate_energy(int n,int k)
{
	long  int  sum[2501],dec;
	int i,j,l;
	sum[1]=0;
	for(i=2;i<=n;i++)
	{
	    sum[i]=sum[i-1];
		for(j=1;j<i;j++)
		sum[i] = sum[i] + A[j][i];
	}	 
for(j=1;j<=n;j++)
  E[1][j]=sum[j] ;	
	for(i=2;i<=n;i++)
	{
		dec=A[i-1][i];
		sum[i]=sum[i]-dec;
		for(l=i+1;l<=n;l++)
		{
           dec=dec+A[i-1][l];
		   sum[l] = sum[l]-dec;
	}  
	  for(j=i+1;j<=n;j++)
	    E[i][j]=sum[j];   
	}
	for(i=1;i<=n;i++)    
	  E[i][i]=0;	
}


void dyn_prog(int i,int j,int l,int r,int *nt)
{
	int t;
	long long int min;
	min=dp[l][j-1]+E[l+1][i];
	*nt=l;
	for(t=l+1;t<=r;t++)
	{
		if(dp[t][j-1]+E[t+1][i]<min)
		{
		min=dp[t][j-1]+E[t+1][i];
		*nt=t;
	}
	}
	dp[i][j]=min;
}


void solve(int j,int low,int high,int l,int r)
{
	int nt;
	if(low>=high)
	{
	dyn_prog(low,j,l,r,&nt);
	return;
}
	else
	{
		int mid;
		mid = (low+high)/2 ;
		dyn_prog(mid,j,l,r,&nt);
		solve(j,low,mid-1,l,nt);
		solve(j,mid+1,high,nt,r);	
		return;
	}
}



int main()
{
	int i,j,n,k;
	long long int r;
	scanf("%d",&n);
	scanf("%d",&k);
	for(i=1;i<=n;i++)
	  for(j=i+1;j<=n;j++)
	  scanf("%d",&A[i][j]);
	  calculate_energy(n,k);	  
	  initialize(n,k);
	  for(j=2;j<=k;j++)
	  solve(j,1,n,1,n);
	  r=dp[n][k];
	  printf("%li",r);
	  printf("\n");
	  exit(0);
}
