#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct list
{
	struct list * next ;
	int val ;
	int de ;
} ;
 
struct Edge
{
    int src, dest;
    long int weight ;
};
 
struct Graph
{
    int V;
    long int E;
    struct Edge* edge;
};
 
long int rel [3001][3001];
struct Edge result[3001]; 
struct list *input[3001] ,*temp[3001];
int visited[3001] ;
struct Graph* graph ;
struct Graph* graph2 ;

struct Graph* createGraph(int V, int E)
{
    struct Graph* graph = (struct Graph*) malloc( sizeof(struct Graph) );
    graph->V = V;
    graph->E = E;
    graph->edge = (struct Edge*) malloc( graph->E * sizeof( struct Edge ) );
    return graph;
}

struct subset
{
    long int parent;
    long int rank;
};
 
long int find(struct subset subsets[], long int i)
{
    if (subsets[i].parent != i)
        subsets[i].parent = find(subsets, subsets[i].parent);
    return subsets[i].parent;
}
 
void Union(struct subset subsets[], long int x, long int y)
{
    int xroot = find(subsets, x);
    int yroot = find(subsets, y);
    if (subsets[xroot].rank < subsets[yroot].rank)
        subsets[xroot].parent = yroot;
    else if (subsets[xroot].rank > subsets[yroot].rank)
        subsets[yroot].parent = xroot;
    else
    {
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
    }
}
 
void merging(long int low, long int mid , long int high)
{
	long int l1,l2,i ;
	for(l1=low,l2=mid+1,i=low; l1<=mid && l2 <=high ; i++) 
	{
	
		if(graph->edge[l1].weight <= graph->edge[l2].weight)
		{
		
		graph2->edge[i].weight = graph->edge[l1].weight ;
		graph2->edge[i].src = graph->edge[l1].src ;
		graph2->edge[i].dest = graph->edge[l1++].dest ;
	    }
		else
		{
		graph2->edge[i].weight = graph->edge[l2].weight ;	
		graph2->edge[i].src = graph->edge[l2].src ;	
		graph2->edge[i].dest = graph->edge[l2++].dest ;	
     	}
	}
		
	while(l1 <= mid)
	{
	graph2->edge[i].weight =graph->edge[l1].weight ;
	graph2->edge[i].src =graph->edge[l1].src ;
	graph2->edge[i++].dest =graph->edge[l1++].dest;
    }
	
	while(l2 <= high)
	{
	graph2->edge[i].weight =graph->edge[l2].weight ;
	graph2->edge[i].src =graph->edge[l2].src ;
	graph2->edge[i++].dest =graph->edge[l2++].dest ;
    }
	
	for(i=low ; i<= high ; i++)
	{
	graph->edge[i].weight =graph2->edge[i].weight ;
	graph->edge[i].src =graph2->edge[i].src ;
	graph->edge[i].dest =graph2->edge[i].dest ;
    }
}

 void sort (long int low , long int high )
 {	
 	long int mid ;
 	if(low<high)
 	{
 	mid = (low + high)/2;
 	sort(low,mid);
 	sort(mid+1,high);
 	merging(low,mid,high);
 }
 else
 return;
 }
 
void KruskalMST(struct Graph* graph)
{
    int V = graph->V;
    long int e = 0;  // An index variable, used for result[]
    long int i = 0;  // An index variable, used for sorted edges   
  
 sort(0,graph->E -1);   
 free(graph2);
    struct subset *subsets =(struct subset*) malloc( V * sizeof(struct subset) );
    for (int v = 0; v < V; ++v)
    {
        subsets[v].parent = v;
        subsets[v].rank = 0;
    }

    while (e < V - 1)
    {
        struct Edge next_edge = graph->edge[i++];
        long int x = find(subsets, next_edge.src);
        long int y = find(subsets, next_edge.dest);
 
        if (x != y)
        {
            result[e++] = next_edge;
            Union(subsets, x, y);
        }
    }
    return;
}

long int max (long int x,long int y)
{
	if (x>y)
	return x;
	else 
	return y;
}


void dfs2(int host ,int v1, long int score)
{
	visited[v1]=1;
	while(temp[v1]!=NULL)
	{
		if(visited[temp[v1]->de] == 0)
		{
		rel[host][temp[v1]->de]=max(score,temp[v1]->val);
		dfs2(host,temp[v1]->de,rel[host][temp[v1]->de]);
	}
	temp[v1]=temp[v1]->next;
	}
}

int main()
{
    int n,V ,v1,v2;
    long int m,q,E,i,j,r;
    scanf("%d",&n);
    scanf("%li",&m);
    V = n;  // Number of vertices in graph
    E = m;  // Number of edges in graph
    graph = createGraph(V, E);
    graph2 = createGraph(V, E);
    
 for(i=0;i<E;i++)
 {
 	scanf("%d",&graph->edge[i].src);
 	graph->edge[i].src = graph->edge[i].src -1;
 	scanf("%d",&graph->edge[i].dest);
 	graph->edge[i].dest= graph->edge[i].dest -1;
 	scanf("%li",&graph->edge[i].weight);
 }

KruskalMST(graph);

for (i = 0; i < V-1 ; ++i)
{
	struct list *l1 = (struct list*)malloc(sizeof(struct list));
	l1->val = result[i].weight;
	l1->next = NULL ;
	l1->de = result[i].dest+1;
	struct list *l2 = (struct list*)malloc(sizeof(struct list));
	l2->val = result[i].weight ;
	l2->next = NULL ;
	l2->de = result[i].src+1;
	if(input[result[i].src+1] != NULL)
	{
	temp[result[i].src+1]->next = l1 ;
	temp[result[i].src+1] = temp[result[i].src+1]->next;
}
	else
	{
	input[result[i].src+1]=l1;
	temp[result[i].src+1]=l1;
}
	if(input[result[i].dest+1]!=NULL)
	{
	temp[result[i].dest+1]->next = l2 ;
	temp[result[i].dest+1]=temp[result[i].dest+1]->next;
}
	else
	{
	input[result[i].dest+1] = l2 ;
	temp[result[i].dest+1] = l2 ;
}

}

for(i=1;i<=V;i++)
{
	for(j=1;j<=V;j++)
	{
	visited[j]=0;
	temp[j]=input[j];
}
dfs2(i,i,0);
}

 scanf("%li",&q);
 for(i=1;i<=q;i++)
 {
 	scanf("%d",&v1);
 	scanf("%d",&v2);
 	printf("%li\n",rel[v1][v2]);
		}       
        
    return 0;
}
