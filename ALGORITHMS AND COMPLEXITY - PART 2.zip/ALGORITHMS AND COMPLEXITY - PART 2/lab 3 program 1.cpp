#include <stdio.h>
#include <stdlib.h>

long long int sum ;
 long int  E ; 
int n;
long int *E1, *E2, *A , *B1, *B2;

struct Edge
{
    unsigned long int src, dest ;
    long int weight;
};

struct Graph
{
    struct Edge* edge;
};

struct Graph* createGraph()
{
    long int i ;
    struct Graph* graph = (struct Graph*) malloc( sizeof(struct Graph) );

    graph->edge = (struct Edge*) malloc( E * sizeof( struct Edge ) );
    for (i = 0; i < (E); i++) {
		graph->edge[i].src = E1[i];
		graph->edge[i].dest = E2[i];
		graph->edge[i].weight = A[i];
    }
    return graph;
}

struct subset
{
    long int parent;
    long int rank;
    unsigned long long int vertex;
};


long int find(struct subset subsets[], long int i)
{
    if (subsets[i].parent != i)
        subsets[i].parent = find(subsets, subsets[i].parent);

    return subsets[i].parent;
}

void Union(struct subset subsets[],long int x,long int y)
{
    long int xroot = find(subsets, x);
    long int yroot = find(subsets, y);

    if (subsets[xroot].rank < subsets[yroot].rank){
        subsets[xroot].parent = yroot;
        subsets[yroot].vertex += subsets[xroot].vertex;
    }
    else if (subsets[xroot].rank > subsets[yroot].rank){
        subsets[yroot].parent = xroot;
        subsets[xroot].vertex += subsets[yroot].vertex;
    }

    else
    {
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
        subsets[xroot].vertex += subsets[yroot].vertex;
    }
}


int comp(const void* a, const void* b)
{
    struct Edge* a1 = (struct Edge*)a;
    struct Edge* b1 = (struct Edge*)b;
    return (a1->weight - b1->weight);
}

void KruskalMST(struct Graph* graph, long int ed)
{
    long int x,y,i;
	long int wght;
    struct Edge next_edge ;
    int edge_cntr = 0;
    long int E;

    E = ed;
    qsort(graph->edge, E, sizeof(graph->edge[0]), comp);
    struct subset *subsets = (struct subset*) malloc( (n+1) * sizeof(struct subset) );
    for (i = 1; i <= n; ++i)
    {
        subsets[i].parent = i;
        subsets[i].rank = 0;
        subsets[i].vertex = 1 ; 
    }
    i = 0 ; 
    while (edge_cntr < n-1)
    {
        next_edge = graph->edge[i++];
        x = find(subsets, next_edge.src);
        y = find(subsets, next_edge.dest);
        wght = next_edge.weight;
        if (x != y) {
            sum += wght;
            edge_cntr++;
            Union(subsets, x, y);
        }
    }
   
    return;
}


int main()
{
    int i,k;
    long long int min;
    long int m;
    struct Graph* graph ;
   	scanf("%d",&n);
    scanf("%d",&k);
    scanf("%li",&m);
    
    E = m + k;

    B1 = (long int *) malloc(k * sizeof(long int));
    B2 = (long int *) malloc(k * sizeof(long int));

    for (i = 0; i<k; i++) {
    	scanf("%li",&B1[i]);
    	scanf("%li",&B2[i]);
    }

    E1 = (long int *) malloc(E * sizeof(long int));
    E2 = (long int *) malloc(E * sizeof(long int));
    A = (long int *) malloc(E * sizeof(long int));

    for (i = 0; i<m; i++) {
    	scanf("%li",&E1[i]);
    	scanf("%li",&E2[i]);
    	scanf("%li",&A[i]);
    }

    for (i = 0; i<k; i++)
	 {
        E1[i+m] = B1[i];
        E2[i+m] = n+1;
        A[i+m] = B2[i];
    }

    graph = createGraph();
    KruskalMST(graph, m);
    min = sum;
    sum = 0;
    n++;
    KruskalMST(graph, E);
    if (sum < min) 
	min = sum;
    printf("%llu\n",min);
    return 0 ;
}
