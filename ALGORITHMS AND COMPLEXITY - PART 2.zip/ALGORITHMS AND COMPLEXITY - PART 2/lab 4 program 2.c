#include <stdio.h>
#include <stdlib.h>

int O[200000];
int ID[200000];
int F[200000];
long int B[200000];
long int S[200000];
long int ind=-1;
int visited[200000];
long int store[400000];
 

 
// A structure to represent a node in adjacency list
struct AdjListNode
{
    long int dest;
    long int weight;
    struct AdjListNode* next;
};
 
// A structure to represent an adjacency liat
struct AdjList
{
    struct AdjListNode *head;  // pointer to head node of list
};
 
// A structure to represent a graph. A graph is an array of adjacency lists.
// Size of array will be V (number of vertices in graph)
struct Graph
{
    long int V;
    struct AdjList* array;
};


struct Graph* graph2 ;
struct Graph* g;
struct AdjListNode* l ;


// A utility function to create a new adjacency list node
struct AdjListNode* newAdjListNode(long int dest,long int weight)
{
    struct AdjListNode* newNode =(struct AdjListNode*) malloc(sizeof(struct AdjListNode));
    newNode->dest = dest;
    newNode->weight = weight;
    newNode->next = NULL;
    return newNode;
}
 
// A utility function that creates a graph of V vertices
struct Graph* createGraph(long int V)
{
	long int i;
    struct Graph* graph = (struct Graph*) malloc(sizeof(struct Graph));
    graph->V = V;
 
    // Create an array of adjacency lists.  Size of array will be V
    graph->array = (struct AdjList*) malloc(V * sizeof(struct AdjList));
 
     // Initialize each adjacency list as empty by making head as NULL
    for ( i = 0; i < V; ++i)
        graph->array[i].head = NULL;
 
    return graph;
}
 
// Adds an edge to an undirected graph
void addEdge(struct Graph* graph,long int src,long int dest,long int weight)
{

	
    // Add an edge from src to dest.  A new node is added to the adjacency
    // list of src.  The node is added at the begining
    struct AdjListNode* newNode = newAdjListNode(dest, weight);
    newNode->next = graph->array[src].head;
    graph->array[src].head = newNode;
}


struct list
{
	long int value ;
	struct list * next ;
} ;

struct list * stak = NULL ;
struct list * last ;


// A recursive function to print DFS starting from v
void DFSUtil(struct Graph* gr ,long int v, int visited[])
{
	struct AdjListNode* ll ;
    // Mark the current node as visited and print it
    visited[v] = 1;
    B[v]=ind;
    S[ind]=S[ind]+F[v];
   if(O[v]==1)
    ID[ind]=1;
    
ll= gr->array[v].head ;
while(ll != NULL)
{ 
   if(!visited[ll->dest])
   DFSUtil(gr,ll->dest,visited);
   ll=ll->next;
}
}
 
 
 
 struct Graph* getTranspose(struct Graph* g ,long int V)
 {
 	long int v ;
 	struct Graph* gg = createGraph(V);
 	for(v=0;v<V;v++)
 	{
 		l= g->array[v].head ;
 		while(l!=NULL)
 		{
 		    addEdge(gg,l->dest,v,1);
			 l=l->next;	
		 }
	 }
 	return(gg);
 }
  

void fillOrder(struct Graph* g ,long int v, int visited[])
{
	struct AdjListNode* ll ;
    // Mark the current node as visited and print it
    visited[v] = 1;       
ll= g->array[v].head ;
while(ll != NULL)
{ 
   if(!visited[ll->dest])
   fillOrder(g,ll->dest,visited);
   ll=ll->next;
}
 struct list* temp = (struct list*) malloc(sizeof(struct list));
  temp->value=v ;
  temp->next = stak ;
  stak = temp ;
return ;
}
 
 
 
// The main function that finds and prints all strongly connected 
// components
void printSCCs(struct Graph* g,long int V)
{
  long int i; 
      // Mark all the vertices as not visited (For first DFS)
    int visited[V];
    for(i = 0; i < V; i++)
        visited[i] = 0;
 
    // Fill vertices in stack according to their finishing times
    for(i = 0; i < V; i++)
    {
        if(visited[i] == 0)
            fillOrder(g,i, visited);
        }
    
   struct  Graph* gr = getTranspose(g,V);
 
    // Mark all the vertices as not visited (For second DFS)
    for( i = 0; i < V; i++)
        visited[i] = 0;
 
    // Now process all vertices in order defined by Stack
    while (stak!=NULL)
    {
        // Pop a vertex from stack
        long int v = stak->value;
        stak = stak->next; 
 
        // Print Strongly connected component of the popped vertex
        if (visited[v] == 0)
        {   ind ++;
            S[ind]=0;
           ID[ind]=0;
           DFSUtil(gr,v, visited);
        }
    }
}

 
 long int DFSfinal(struct AdjListNode* ll , long int max,int valid)
 {
 	long int temp,m ;
 	int vv;
 	if(valid==1)
 	m=max;
 	else
 	m=-1;
 	while(ll!=NULL)
 	{
 		vv=valid;
 		visited[ll->dest]++;
 		l= graph2->array[ll->dest].head ;
 		if(ID[ll->dest]==1)
 		vv=1;
 		if(visited[ll->dest]<2)
 		temp=DFSfinal(l,max + S[ll->dest],ID[ll->dest]);
 		else
 		temp=DFSfinal(l,max,ID[ll->dest]);
 		visited[ll->dest]--;
 		if(temp>m)
 		m=temp;
 		ll=ll->next;
	 }
	 return(m);
 }
 
 
 
// Driver program to test above functions
int main()
{
	long int i,n,m,u,v,r;
	scanf("%li",&n);
	scanf("%li",&m);
	g = createGraph(n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&O[i]);
		scanf("%d",&F[i]);
	}
	for(i=0;i<m;i++)
	{
		scanf("%li",&u);
		scanf("%li",&v);
		store[2*i]=u-1;
		store[2*i+1]=v-1;
		addEdge(g,u-1, v-1,1);
	}

 printSCCs(g,n);
 
graph2 = createGraph(ind+1);

for(i=0;i<m;i++)
{
	u=store[2*i];
	v=store[2*i+1];
	if(B[u]!=B[v] )
	{
	addEdge(graph2,B[u],B[v],S[u]);
}
}

l= graph2->array[B[0]].head ;


for(i=0;i<=ind;i++)
visited[i]=0;
visited[B[0]]=1;
r=DFSfinal(l,S[B[0]],ID[B[0]]);
printf("%li",r);
printf("\n");
    return 0;
}

